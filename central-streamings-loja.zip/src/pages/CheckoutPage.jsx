import React from "react";
import { useCart } from "../context/CartContext";

export default function CheckoutPage() {
  const { cart, removeFromCart, clearCart } = useCart();

  const total = cart.reduce((sum, item) => sum + item.price * item.qty, 0);
  const pixKey = "51405501804";
  const pixMessage = `Central Streamings - Total: R$ ${total.toFixed(2)}`;
  const pixCode = `00020126580014BR.GOV.BCB.PIX01${pixKey.length}${pixKey}520400005303986540${total.toFixed(2).replace('.', '')}5802BR5920Central Streamings6009Sao Paulo62100506stream6304ABCD`;

  return (
    <div className="p-4 text-white bg-black min-h-screen">
      <h1 className="text-2xl font-bold mb-4">Checkout</h1>
      {cart.length === 0 ? (
        <p>Carrinho vazio.</p>
      ) : (
        <div>
          <ul className="mb-4">
            {cart.map((item) => (
              <li key={item.id} className="mb-2">
                {item.qty}x {item.name} - R$ {(item.price * item.qty).toFixed(2)}
                <button onClick={() => removeFromCart(item.id)} className="ml-4 text-red-500">
                  Remover
                </button>
              </li>
            ))}
          </ul>
          <p className="mb-2">Total: <strong>R$ {total.toFixed(2)}</strong></p>
          <p className="mb-2">Chave Pix: <strong>{pixKey}</strong></p>
          <p className="mb-2">Pix Copia e Cola:</p>
          <textarea
            className="w-full p-2 text-black rounded mb-4"
            rows="4"
            readOnly
            value={pixMessage + "\n" + pixCode}
          />
          <button onClick={() => { navigator.clipboard.writeText(pixCode); alert("Código Pix copiado!"); }} className="bg-blue-500 text-white px-4 py-2 rounded mr-2">
            Copiar código Pix
          </button>
          <button onClick={clearCart} className="bg-gray-700 text-white px-4 py-2 rounded">
            Limpar carrinho
          </button>
        </div>
      )}
    </div>
  );
}
