import React, { useEffect, useState } from "react";
import { useAuth } from "../lib/AuthContext";

export default function Dashboard() {
  const { user } = useAuth();
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    if (user) {
      setOrders([
        { id: "PED123", items: ["Spotify Anual", "YouTube Premium Mensal"], total: 40, status: "Aguardando pagamento" },
        { id: "PED122", items: ["Deezer Mensal"], total: 17, status: "Concluído" }
      ]);
    }
  }, [user]);

  if (!user) return <p className="text-white p-4">Faça login para ver seus pedidos.</p>;

  return (
    <div className="p-4 text-white bg-black min-h-screen">
      <h1 className="text-2xl font-bold mb-4">Seus pedidos</h1>
      {orders.map((order) => (
        <div key={order.id} className="bg-zinc-900 p-4 rounded-xl mb-4">
          <p className="font-semibold">Pedido: {order.id}</p>
          <p>Produtos: {order.items.join(", ")}</p>
          <p>Total: R$ {order.total.toFixed(2)}</p>
          <p>Status: <span className="text-yellow-400">{order.status}</span></p>
        </div>
      ))}
    </div>
  );
}
