import React from "react";
import products from "../data/products";
import { useCart } from "../context/CartContext";

export default function HomePage() {
  const { addToCart } = useCart();

  return (
    <div className="p-4 text-white bg-black min-h-screen">
      <h1 className="text-2xl font-bold mb-4">Central Streamings</h1>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {products.map((product) => (
          <div key={product.id} className="bg-zinc-900 rounded-xl p-4 shadow hover:shadow-lg">
            <h2 className="text-lg font-semibold">{product.name}</h2>
            <p className="mb-2">R$ {product.price.toFixed(2)}</p>
            <button
              onClick={() => addToCart(product)}
              className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded"
            >
              Adicionar ao carrinho
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
